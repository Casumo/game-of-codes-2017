java -Xms128m -Xmx4g -XX:+UseConcMarkSweepGC -jar journey-1.0-SNAPSHOT.jar $1 $2
